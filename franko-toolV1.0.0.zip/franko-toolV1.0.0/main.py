from telethon import TelegramClient
import os
import json
import importlib

CONFIG_FILE = "config.json"
MODULES_DIR = "modules"

def load_config():
    if not os.path.exists(CONFIG_FILE):
        data = {"api_id": "", "api_hash": ""}
    else:
        with open(CONFIG_FILE) as f:
            data = json.load(f)

    if not data["api_id"] or not data["api_hash"]:
        data["api_id"] = int(input("API ID: "))
        data["api_hash"] = input("API HASH: ")

        with open(CONFIG_FILE, "w") as f:
            json.dump(data, f)

    return data

config = load_config()

client = TelegramClient("franko_session", config["api_id"], config["api_hash"])

def load_modules():
    for file in os.listdir(MODULES_DIR):
        if file.endswith(".py"):
            module = importlib.import_module(f"{MODULES_DIR}.{file[:-3]}")
            if hasattr(module, "auto-sub):
                module.auto-sub(client)

load_modules()

client.start()
print("🔥 Franko Tool запущен!")

client.run_until_disconnected()