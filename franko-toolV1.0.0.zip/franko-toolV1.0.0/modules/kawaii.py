from telethon import events
import random

# ==========================
# KAWAII ENGINE
# ==========================

class KawaiiModeDeep:
    def __init__(self):
        self.user_settings = {}

        self.cyrillic = {
            'а': ['а', 'α', 'ａ', '@'],
            'б': ['б', 'β', 'ｂ'],
            'в': ['в', 'ν', 'ｖ'],
            'г': ['г', 'γ', 'ｇ'],
            'д': ['д', '∂', 'ｄ'],
            'е': ['е', 'ε', 'ｅ', 'ё'],
            'з': ['з', 'ζ', 'ｚ'],
            'и': ['и', 'η', 'ｉ'],
            'к': ['к', 'κ', 'ｋ'],
            'м': ['м', 'μ', 'ｍ'],
            'н': ['н', 'ν', 'ｎ'],
            'о': ['о', 'ο', 'ｏ', '○', '●'],
            'п': ['п', 'π', 'ｐ'],
            'р': ['р', 'ρ', 'ｒ'],
            'с': ['с', 'σ', 'ｃ', '$'],
            'т': ['т', 'τ', 'ｔ'],
            'у': ['у', 'υ', 'ｕ'],
            'х': ['х', 'χ', 'ｘ'],
            'я': ['я', 'ａ']
        }

        self.latin = {
            'a': ['α', '@', 'ａ'],
            'e': ['ε', 'ｅ'],
            'o': ['ο', '○', 'ｏ'],
            'x': ['χ', '×', 'ｘ'],
            's': ['ѕ', '$']
        }

        self.kaomoji = [
            '(◕‿◕)', '(｡♥‿♥｡)', '(づ｡◕‿‿◕｡)づ',
            '☆(≧▽≦)', '٩(◕‿◕｡)۶'
        ]

        self.suffixes = ['〜', '☆', '💕', '✨', '🌸']

    def transform(self, text):
        result = ""
        words = text.split(" ")

        for i, word in enumerate(words):
            new_word = ""

            for char in word:
                lower = char.lower()

                if lower in self.cyrillic:
                    new_word += random.choice(self.cyrillic[lower])
                elif lower in self.latin:
                    new_word += random.choice(self.latin[lower])
                else:
                    new_word += char

            # суффикс
            if random.random() < 0.6:
                new_word += random.choice(self.suffixes)

            result += new_word

            # каомодзи
            if i % random.randint(2, 4) == 0:
                result += " " + random.choice(self.kaomoji)

            result += " "

        return result.strip()

    def toggle(self, user_id):
        state = self.user_settings.get(user_id, False)
        new_state = not state
        self.user_settings[user_id] = new_state
        return new_state

    def is_active(self, user_id):
        return self.user_settings.get(user_id, False)


kawaii = KawaiiModeDeep()

# ==========================
# COMMANDS
# ==========================

def register(client):

    @client.on(events.NewMessage(pattern=r"\.kawaii"))
    async def kawaii_toggle(event):
        user_id = event.sender_id
        state = kawaii.toggle(user_id)

        if state:
            await event.edit("🌸✨ ПИКМИ РЕЖИМ ВКЛЮЧЕН ✨🌸")
        else:
            await event.edit("❌ ПИКМИ РЕЖИМ ВЫКЛЮЧЕН")

    @client.on(events.NewMessage)
    async def kawaii_handler(event):
        user_id = event.sender_id

        # не трогаем команды
        if event.raw_text.startswith("."):
            return

        if kawaii.is_active(user_id):
            try:
                new_text = kawaii.transform(event.raw_text)

                # редактируем только свои сообщения
                if event.out:
                    await event.edit(new_text)
            except:
                pass