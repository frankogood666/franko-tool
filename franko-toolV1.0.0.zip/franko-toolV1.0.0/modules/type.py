from telethon import events
import asyncio

@client.on(events.NewMessage(pattern=r"\.type(?: |$)(.*)"))
async def type_animation(event):
    input_text = event.pattern_match.group(1)
    
    # если текста нет — берём из ответа
    if not input_text:
        reply = await event.get_reply_message()
        if not reply or not reply.text:
            await event.edit("❌ Нет текста")
            return
        text = reply.text
    else:
        text = input_text

    # удаляем команду
    await event.delete()

    message = await event.respond("⌨️ ...")
    typed = ""

    for char in text:
        typed += char
        try:
            await message.edit(typed + "▌")
        except:
            pass
        await asyncio.sleep(0.05)

    await message.edit(typed)