from telethon import events
import requests
from datetime import datetime, timedelta
import os
import json
import asyncio

USAGE_FILE = "ip_usage.txt"
DAILY_LIMIT = 10

def save_usage(start_time: datetime, count: int):
    with open(USAGE_FILE, "w") as f:
        data = {
            "start_time": start_time.isoformat(),
            "count": count
        }
        json.dump(data, f)

def load_usage():
    if not os.path.exists(USAGE_FILE):
        return None, 0
    with open(USAGE_FILE, "r") as f:
        try:
            data = json.load(f)
            start_time = datetime.fromisoformat(data["start_time"])
            count = data["count"]
            return start_time, count
        except:
            return None, 0

def get_ip_info(ip_address):
    url = f"https://ipinfo.io/{ip_address}/json"
    response = requests.get(url)
    return response.json()

def get_ip_type(ip_address):
    url = f"https://ipwho.is/{ip_address}"
    response = requests.get(url)
    return response.json()

def format_ip_info(ip_address):
    ip_info = get_ip_info(ip_address)
    ip_type_info = get_ip_type(ip_address)

    result = "ОБЩАЯ ИНФОРМАЦИЯ:\n"
    result += f"IP: {ip_info.get('ip', 'недоступен')}\n"
    result += f"Город: {ip_info.get('city', 'недоступен')}\n"
    result += f"Регион: {ip_info.get('region', 'недоступен')}\n"
    result += f"Континент: {ip_type_info.get('continent', 'недоступен')} ({ip_type_info.get('continent_code', '')})\n"
    result += f"Страна: {ip_type_info.get('country', 'недоступна')} ({ip_type_info.get('country_code', '')})\n"
    result += f"Индекс: {ip_type_info.get('postal', 'недоступен')}\n"
    result += f"Код телефона: +{ip_type_info.get('calling_code', '')}\n"
    result += f"Языки: {ip_type_info.get('languages', '')}\n"
    result += f"Время: {ip_info.get('timezone', 'недоступно')}\n\n"

    result += "ГЕОЛОКАЦИЯ:\n"
    if 'loc' in ip_info:
        latitude, longitude = ip_info['loc'].split(',')
        result += f"Координаты: {ip_info['loc']}\n"
        result += f"Google Maps: https://www.google.com/maps?q={latitude},{longitude}\n"
        result += f"Yandex Maps: https://yandex.ru/maps/?ll={longitude},{latitude}&z=10\n\n"
    else:
        result += "Координаты недоступны\n\n"

    result += "ТЕХНИЧЕСКАЯ ИНФОРМАЦИЯ:\n"
    result += f"Тип: {ip_type_info.get('type', 'недоступен')}\n"
    result += f"Hostname: {ip_info.get('hostname', 'недоступен')}\n"
    result += f"Организация: {ip_info.get('org', 'недоступна')}\n\n"

    result += "IoT-ПРОВЕРКИ:\n"
    result += f"Shodan: https://www.shodan.io/search?query={ip_address}\n"
    result += f"Censys: https://censys.io/ipv4/{ip_address}\n"
    result += f"ZoomEye: https://www.zoomeye.org/searchResult?q={ip_address}\n"
    result += f"CriminalIP: https://www.criminalip.io/asset/report/{ip_address}\n"
    result += f"VirusTotal: https://www.virustotal.com/gui/ip-address/{ip_address}\n"

    return result

def register(client):
    @client.on(events.NewMessage(pattern=r"\.ip\s+(.+)"))
    async def handler(event):
        ip = event.pattern_match.group(1).strip()
        now = datetime.now()

        start_time, count = load_usage()

        if not start_time or now - start_time >= timedelta(hours=24):
            start_time = now
            count = 0
            save_usage(start_time, count)

        if count >= DAILY_LIMIT:
            next_reset = start_time + timedelta(hours=24)
            time_left = next_reset - now
            hours = time_left.seconds // 3600
            minutes = (time_left.seconds % 3600) // 60
            await event.edit(f"Лимит на сегодня исчерпан.\nПопробуйте снова через {hours} ч. {minutes} мин.")
            return

        try:
            progress_bar_template = "[{bar}] {percent}%"
            total_blocks = 20

            loading_message = await event.edit("Ищу информацию об IP...\n[░" + "░"*(total_blocks-1) + "] 0%")

            async def fake_progress():
                for i in range(1, total_blocks + 1):
                    bar = "█" * i + "░" * (total_blocks - i)
                    percent = int((i / total_blocks) * 100)
                    await loading_message.edit(f"Ищу информацию об IP...\n{progress_bar_template.format(bar=bar, percent=percent)}")
                    await asyncio.sleep(0.07)

            await fake_progress()

            result = format_ip_info(ip)
            count += 1
            save_usage(start_time, count)
            await loading_message.edit(f"Информация об IP **{ip}**:\n\n{result}")
        except Exception as e:
            await event.edit(f"Ошибка: {e}")

    @client.on(events.NewMessage(pattern=r"\.countip$", outgoing=True))
    async def ip_count(event):
        now = datetime.now()
        start_time, count = load_usage()

        if not start_time or now - start_time >= timedelta(hours=24):
            remaining = DAILY_LIMIT
            time_left_str = "Лимит уже сброшен."
        else:
            remaining = DAILY_LIMIT - count
            next_reset = start_time + timedelta(hours=24)
            time_left = next_reset - now
            hours = time_left.seconds // 3600
            minutes = (time_left.seconds % 3600) // 60
            time_left_str = f"{hours} ч. {minutes} мин."

        await event.edit(
            f"Использований IP-команды: {count}/{DAILY_LIMIT}\n"
            f"Осталось: {remaining}\n"
            f"Сброс через: {time_left_str}"
        )
        