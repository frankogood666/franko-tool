from telethon import events

def register(client):
    @client.on(events.NewMessage(pattern=r"\.help", outgoing=True))
    async def help_cmd(event):
        text = (
            "╭───『 ⚙️ Franko Tool 』───╮\n\n"

            "📌 **Основные команды:**\n"
            "• `.ping` — пинг бота\n"
            "• `.uptime` — время работы\n"
            "• `.help` — это меню\n\n"

            "📦 **Система:**\n"
            "• `.update` — обновить тул\n"
            "• `.lm` — загрузка модулей (в разработке)\n\n"

            "💥 **Активность:**\n"
            "• `.spam <кол-во> <текст>` — спам\n\n"

            "🌐 **Утилиты:**\n"
            "• `.ip <ip>` — инфа по IP\n"
            "• `.dox` — поиск инфы\n\n"

            "🎭 **Развлечения:**\n"
            "• `.8ball` — предсказание\n"
            "• `.kawaii <текст>` — стиль текста\n"
            "• `.type <текст>` — печать\n"
            "• `.petpet` — gif (реплай на фото)\n"
            "• `.music <название>` — поиск музыки\n\n"

            "╰──────────────────────╯"
        )
        await event.edit(text)