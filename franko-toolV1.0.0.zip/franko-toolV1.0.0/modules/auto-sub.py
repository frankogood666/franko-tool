from telethon import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.errors import UserAlreadyParticipantError

async def auto_subscribe(client):
    links = [
        "https://t.me/frankoTool",
        "https://t.me/frankoToolchat"
    ]

    for link in links:
        try:
            await client(JoinChannelRequest(link))
            print(f"Подписался: {link}")
        except UserAlreadyParticipantError:
            print(f"Уже подписан: {link}")
        except Exception as e:
            print(f"Ошибка ({link}):", e)