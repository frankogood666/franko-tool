from datetime import datetime, timedelta
from telethon import events

last_response = {}
response_text = ""
cooldown_time = timedelta(days=1)

exclude_contacts = False
excluded_ids = set()

def register(client):
    @client.on(events.NewMessage(pattern=r"^\.respond (on|off)(?:\s+(.*))?", outgoing=True))
    async def toggle_responder(event):
        global response_text
        command = event.pattern_match.group(1)
        text = event.pattern_match.group(2)
        
        if command == "on" and text:
            response_text = text
            await event.edit("Автоответчик включен.")
        elif command == "off":
            response_text = ""
            await event.edit("Автоответчик отключен.")
        else:
            await event.edit("Использование:\n.respond on <текст>\n.respond off")

    @client.on(events.NewMessage(pattern=r"^\.respond ([+-])contacts", outgoing=True))
    async def toggle_contacts_exclusion(event):
        global exclude_contacts
        sign = event.pattern_match.group(1)
        exclude_contacts = (sign == "-")
        status = "не отвечать контактам" if exclude_contacts else "снова отвечать контактам"
        await event.edit(f"Автоответчик теперь будет {status}.")

    @client.on(events.NewMessage(pattern=r"^\.respond ([+-])id (\d+)", outgoing=True))
    async def toggle_id_exclusion(event):
        global excluded_ids
        sign = event.pattern_match.group(1)
        user_id = int(event.pattern_match.group(2))

        if sign == "-":
            excluded_ids.add(user_id)
            await event.edit(f"Автоответчик отключен для пользователя с ID {user_id}.")
        else:
            excluded_ids.discard(user_id)
            await event.edit(f"Автоответчик включен для пользователя с ID {user_id}.")

    @client.on(events.NewMessage(incoming=True))
    async def auto_respond(event):
        global last_response, response_text, cooldown_time
        if not response_text or not event.is_private:
            return

        sender = await event.get_sender()
        if sender is None or sender.bot:
            return

        user_id = sender.id

        if user_id in excluded_ids:
            return
        if exclude_contacts and sender.contact:
            return

        now = datetime.now()
        if user_id not in last_response or now - last_response[user_id] >= cooldown_time:
            last_response[user_id] = now
            await event.reply(response_text)
            