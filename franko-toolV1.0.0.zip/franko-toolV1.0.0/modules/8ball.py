from telethon import events
import random
import asyncio

positive = [
    "Да", "Определённо да", "Без сомнений", "Конечно", "100%", "Ещё как да"
]

negative = [
    "Нет", "Определённо нет", "Ни за что", "Даже не надейся", "Маловероятно"
]

neutral = [
    "Возможно", "Спроси позже", "Не уверен", "Сложно сказать", "Время покажет"
]

funny = [
    "Спроси у мамы",
    "Гугл в помощь",
    "Я шар, а не оракул 😏",
    "Ты серьёзно сейчас?",
    "Да, но только во сне"
]

all_answers = positive + negative + neutral + funny

@client.on(events.NewMessage(pattern=r"\.8ball(?: |$)(.*)"))
async def magic_ball(event):
    question = event.pattern_match.group(1)

    # если нет текста — берём из reply
    if not question:
        reply = await event.get_reply_message()
        if not reply or not reply.text:
            await event.edit("❌ Задай вопрос")
            return
        question = reply.text

    # анимация "думает"
    msg = await event.edit("🎱 Думаю...")
    for i in range(3):
        await asyncio.sleep(0.5)
        try:
            await msg.edit("🎱 Думаю" + "." * (i + 1))
        except:
            pass

    answer = random.choice(all_answers)

    await msg.edit(
        f"🎱 Вопрос: {question}\n"
        f"💬 Ответ: {answer}"
    )