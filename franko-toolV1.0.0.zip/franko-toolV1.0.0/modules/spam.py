from telethon import events
import asyncio

@client.on(events.NewMessage(pattern=r"\.spam (\d+) (.+)"))
async def spam(event):
    count = int(event.pattern_match.group(1))
    text = event.pattern_match.group(2)

    # защита от слишком большого спама
    if count > 300:
        await event.edit("❌ Слишком много (макс: 300)")
        return

    await event.delete()

    for i in range(count):
        try:
            await event.respond(text)
            await asyncio.sleep(0.3)  # задержка (анти-спам)
        except Exception as e:
            print("Ошибка:", e)
            break