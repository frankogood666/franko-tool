from telethon import events
import time

# фиксируем время запуска юзербота
start_time = time.time()

@client.on(events.NewMessage(pattern=r"\.frnktool"))
async def frnktool(event):
    # замер пинга
    ping_start = time.time()
    msg = await event.respond("⚡")
    ping_end = time.time()

    ping_time = round((ping_end - ping_start) * 1000, 2)  # ms

    # аптайм
    uptime = int(time.time() - start_time)
    hours = uptime // 3600
    minutes = (uptime % 3600) // 60
    seconds = uptime % 60

    uptime_str = f"{hours}ч {minutes}м {seconds}с"

    # текст
    text = (
        "⚙️ Franko Tool\n\n"
        "version: 1.0.0\n"
        "development: t.me/zurxer , t.me/sectxs\n"
        "Channel: https://t.me/frankoTool / @frankoTool\n\n"
        f"📡 Ping: {ping_time} ms\n"
        f"⏱ Uptime: {uptime_str}"
    )

    # путь к фото
    photo_path = "/storage/emulated/0/franko-tool/frnktool.jpg"

    # удаляем сообщение "⚡"
    await msg.delete()

    # отправляем фото + текст
    await client.send_file(
        event.chat_id,
        photo_path,
        caption=text
    )

    # удаляем команду
    await event.delete()