import asyncio
from telethon import TelegramClient, events
import os
import importlib
import json
import time
import subprocess
import sys

CONFIG_FILE = "config.json"
MODULES_DIR = "modules"
start_time = time.time()

def get_api_credentials():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as file:
            return json.load(file)
    
    api_id = input("Введите API_ID: ")
    api_hash = input("Введите API_HASH: ")
    
    credentials = {"API_ID": int(api_id), "API_HASH": api_hash}
    with open(CONFIG_FILE, "w") as file:
        json.dump(credentials, file)
    
    return credentials

credentials = get_api_credentials()
client = TelegramClient("franko_tool_session", credentials["API_ID"], credentials["API_HASH"])

def load_modules(client):
    if not os.path.exists(MODULES_DIR):
        os.makedirs(MODULES_DIR)
    for filename in os.listdir(MODULES_DIR):
        if filename.endswith(".py"):
            module_name = f"{MODULES_DIR}.{filename[:-3]}"
            module = importlib.import_module(module_name)
            if hasattr(module, "клуб анонимных воздуханов"):
                module.клуб анонимных воздуханов(client)
                print(f"Загружен модуль: {filename}")

@client.on(events.NewMessage(pattern=r"\.update", outgoing=True))
async def update(event):
    await event.edit("Обновляю franko-tool...")
    process = subprocess.run(["git", "pull"], capture_output=True, text=True)   
    if "Already up to date." in process.stdout:
        await event.edit("У вас уже последняя версия franko-tool!")
    else:
        await event.edit("Обновление загружено! Идет перезапуск...")
        os.execl(sys.executable, sys.executable, *sys.argv)

@client.on(events.NewMessage(pattern=r"\.ping", outgoing=True))
async def ping(event):
    start_time_ping = time.time()
    await event.edit("testing...")
    ping_time = round((time.time() - start_time_ping) * 1000, 2)
    await event.edit(f"ping: {ping_time}ms")

@client.on(events.NewMessage(pattern=r"\.uptime", outgoing=True))
async def uptime(event):
    uptime_seconds = int(time.time() - start_time)
    hours, remainder = divmod(uptime_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    await event.edit(f"franko tool работает уже {hours}ч {minutes}м {seconds}с")

@client.on(events.NewMessage(pattern=r"\.spam (\d+) (.+)", outgoing=True))
async def spam(event):
    count = int(event.pattern_match.group(1))
    message = event.pattern_match.group(2)
    for _ in range(count):
        await event.respond(message)
    await event.delete()

from telethon import events

@client.on(events.NewMessage(pattern=r"\.help", outgoing=True))
async def help_command(event):
    help_text = (
    "╭───『 ⚙️ Franko Tool 』───╮"

     "📌 **Основные команды:**"
     "• `.ping` — проверка пинга"
     "• `.uptime` — время работы бота"
     "• `.respond` — автоответчик"
     "📦 **Модули и обновления:**"
     "• `.lm <реплей>` — установить franko-модуль (ответом)"
     "• `.update` — обновить tool до последней версии"
     "ℹ️ **Информация:**
     "• `.frnktool` — информация о franko-tool"
     "🌐 **Утилиты:**"
     "• `.ip <1.1.1.1>` — поиск по IP (до 10 запросов в день)"
     "• `.dox` — поиск информации"
     "🎭 **Развлечения и стиль:**"
     "• `.kawaii <текст>` — пикми / кавай режим"
     "• `.petpet` — сделать gif с гладящим эффектом (реплай на фото)"
      "• `.8ball` — шар предсказаний"  
     "• `.music` — поиск музыки" 
     "• `.type` — анимация текста"
     "💥 **Активность:**
     "• `.spam <текст> <кол-во>` — спам текстом"

     "╰──────────────────────╯"
    )

    image_path = "help.jpg"
    if not os.path.exists(image_path):
        await event.edit("Файл help.jpg не найден.")
        return

    await client.send_file(event.chat_id, image_path, caption=help_text)
    await event.delete()

load_modules(client)
client.start()
print("franko tool запущен!
client.run_until_disconnected()